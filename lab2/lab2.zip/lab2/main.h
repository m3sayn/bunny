#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#include <windows.h>
#include <gl/gl.h>
#include <stdio.h>
#include <stdlib.h>
#include "stb-master/stb_easy_font.h"
#include "menu.h"

int width = 700;
int height = 500;
int gameState=0;


void Menu_Init(){
    Menu_AddButton("GO", 10.0,10.0,100.0,30.0, 2);
    Menu_AddButton("STOP", 10.0,50.0,100.0,30.0,2);
    Menu_AddButton("Quit", 10.0,90.0,100.0,30.0,2);
}

#endif // MAIN_H_INCLUDED
