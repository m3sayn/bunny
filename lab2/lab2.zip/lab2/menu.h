#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED



int Menu_AddButton(char *name, float x, float y, float width, float height, float textS);
void Menu_ShowMenu();

#endif // MENU_H_INCLUDED
